<?php
$localhost = 'mysql.hostinger.in';
$username = 'u902470907_root';
$password = 'asdfghjk';


 $con=mysql_connect($localhost,$username,$password) or exit('connection to db failed');
  mysql_select_db('u902470907_fpk') or exit('unable to contact');
?>